import configparser

import matplotlib.pyplot as plt
import seaborn as sns


# 从文件中读取日志信息
def read_log_file(file_path):
    with open(file_path, 'r') as file:
        return file.readlines()


# 分析日志，提取所需的统计数据
def analyze_log(log_lines):
    new_count = 0
    timeout_count = 0
    retransmit = 0

    for line in log_lines:
        if "STATUS=OK" in line:
            new_count += 1
        elif "STATUS=NoErr" in line:
            timeout_count += 1
        elif "STATUS=DataErr" in line:
            retransmit += 1

    return new_count, timeout_count, retransmit


# 使用matplotlib绘制图表
def plot_data(new_count, timeout_count, retransmit):
    config = configparser.ConfigParser()
    config.read('config.ini')
    send_ip = config.get('send', 'ip')
    receiver_ip = config.get('receive', 'ip')
    send_port = config.getint('send', 'port')
    receiver_port = config.getint('receive', 'port')
    window_size = config.getint('protocol', 'window_size')
    data_size = config.getint('protocol', 'data_length')
    error_rate = config.getfloat('protocol', 'Error_rate') / 100.0
    lost_rate = config.getfloat('protocol', 'Lost_rate') / 100.0

    # 使用seaborn设置样式
    sns.set(style='whitegrid', font_scale=1.2)

    # 绘制饼图
    labels = ['New', 'Timeout', 'RT']
    sizes = [new_count, timeout_count, retransmit]
    colors = ['#66b3ff', '#ff9999', '#ff93ff']
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90, pctdistance=0.85)

    # 绘制白色圆圈
    centre_circle = plt.Circle((0, 0), 0.70, fc='white')
    fig = plt.gcf()
    fig.gca().add_artist(centre_circle)
    plt.axis('equal')

    # 添加标题和配置信息
    plt.title('Packet Transmission Status\n'
              f'Send IP: {send_ip} | Receive IP: {receiver_ip}\n'
              f'Send Port: {send_port} | Receive Port: {receiver_port}\n'
              f'Window Size: {window_size} | Data Size: {data_size}\n'
              f'Error Rate: {error_rate} | Lost Rate: {lost_rate}\n'
              f'time cost:360.06s')

    plt.tight_layout()
    plt.show()


def main():
    log_lines = read_log_file('10.171.66.22_42944_log_file.txt')
    new_count, timeout_count, retransmit = analyze_log(log_lines)
    plot_data(new_count, timeout_count, retransmit)


if __name__ == '__main__':
    main()
