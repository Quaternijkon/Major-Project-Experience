import os
import socket
import unittest
from io import StringIO
from unittest.mock import patch

import main


class TestProgram(unittest.TestCase):

    def setUp(self):
        self.config = """
        [send]
        ip = 127.0.0.1
        port = 8000
        filename = test.txt

        [receive]
        ip = 127.0.0.1
        port = 8001
        filename = ./received_files/
        """
        with open('config.ini', 'w') as f:
            f.write(self.config)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def tearDown(self):
        os.remove('config.ini')
        self.sock.close()

    def test_send(self):
        with patch('builtins.input', side_effect=['send', '127.0.0.1', '8000', 'test.txt', '127.0.0.1', '8001']), \
                patch('host.sender.send', return_value=None):
            main()

    def test_receive(self):
        with patch('builtins.input', side_effect=['receive', '127.0.0.1', '8001', './received_files/']), \
                patch('host.receiver.receive', return_value=None):
            main()

    def test_invalid_option(self):
        with patch('builtins.input', side_effect=['invalid', 'close']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(), "Invalid option. Please enter 'send', 'receive', or 'close'.")

    def test_invalid_send_ip(self):
        with patch('builtins.input', side_effect=['send', 'invalid', '8000', 'test.txt', '127.0.0.1', '8001']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(), "Invalid IP address. Please enter a valid IP address.")

    def test_invalid_send_port(self):
        with patch('builtins.input', side_effect=['send', '127.0.0.1', 'invalid', 'test.txt', '127.0.0.1', '8001']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(), "Invalid port number. Please enter a valid integer.")

    def test_invalid_send_file_path(self):
        with patch('builtins.input', side_effect=['send', '127.0.0.1', '8000', 'invalid', '127.0.0.1', '8001']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(), "Invalid file path. Please enter a valid file path.")

    def test_invalid_receive_ip(self):
        with patch('builtins.input', side_effect=['receive', 'invalid', '8001', './received_files/']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(), "Invalid IP address. Please enter a valid IP address.")

    def test_invalid_receive_port(self):
        with patch('builtins.input', side_effect=['receive', '127.0.0.1', 'invalid', './received_files/']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(), "Invalid port number. Please enter a valid integer.")

    def test_invalid_receive_dir_path(self):
        with patch('builtins.input', side_effect=['receive', '127.0.0.1', '8001', 'invalid']), \
                patch('sys.stdout', new_callable=StringIO) as fake_out:
            main()
            self.assertEqual(fake_out.getvalue().strip(),
                             "Invalid directory path. Please enter a valid directory path.")

    def test_close_option(self):
        with patch('builtins.input', side_effect=['close']), \
                patch('sys.exit') as mock_exit:
            main()
            mock_exit.assert_called_once_with()
