import time
import unittest

from timer import Timer


class TestTimer(unittest.TestCase):
    def setUp(self):
        self.timer = Timer(5)

    def test_start(self):
        self.timer.satrt(0)
        self.assertEqual(len(self.timer._TIMER), 1)

    def test_get_time(self):
        curr_time = Timer.get_time()
        self.assertIsInstance(curr_time, float)

    def test_overtime_true(self):
        self.timer.satrt(0)
        time.sleep(6)
        self.assertTrue(self.timer.overtime(0))

    def test_overtime_false(self):
        self.timer.satrt(0)
        time.sleep(4)
        self.assertFalse(self.timer.overtime(0))

    def test_overtime_out_of_range(self):
        self.timer.satrt(0)
        time.sleep(6)
        self.assertTrue(self.timer.overtime(1))
