# timer.py

import time


class Timer:
    """计时器"""
    TIMER_STOP = -1
    _TIMER = {}

    def __init__(self, _interval):
        self.start_time = self.TIMER_STOP
        self.interval = _interval

    def satrt(self, seq):
        """开始计时"""
        self._TIMER[seq] = time.time()

    @staticmethod
    def get_time():
        """获取当前时间"""
        return time.time()

    def overtime(self, seq):
        """判断是否超时"""
        if seq >= len(self._TIMER):
            seq -= 1
        if time.time() - self._TIMER[seq] > self.interval:
            return True
        else:
            return False
