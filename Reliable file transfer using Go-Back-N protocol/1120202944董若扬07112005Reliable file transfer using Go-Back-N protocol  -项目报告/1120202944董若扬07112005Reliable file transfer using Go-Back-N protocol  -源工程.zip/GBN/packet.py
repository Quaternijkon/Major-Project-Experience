def packing(seq_num, crc_num, data=b''):
    # 检查输入类型是否正确
    if not isinstance(seq_num, int):
        raise TypeError('Please provide an integer value for the sequence number.')
    if not isinstance(crc_num, int):
        raise TypeError('Please provide an integer value for the CRC number.')
    if not isinstance(data, bytes):
        raise TypeError('Please provide a byte string for the data.')

    # 使用小端字节顺序将序列号转换为字节
    seq_bytes = seq_num.to_bytes(4, byteorder='little', signed=True)

    # 使用小端字节顺序将CRC转换为字节
    crc_bytes = crc_num.to_bytes(4, byteorder='little', signed=True)

    # 将序列号、CRC号和数据连接在一起
    packed_data = seq_bytes + crc_bytes + data

    # 返回打包后的数据
    return packed_data


def pack_empty():
    try:
        # 返回一个空的bytes值
        return b''
    except Exception as e:
        # 记录异常
        print(f"An exception occurred: {type(e).__name__}: {e}")
        # 返回一个空的bytes值
        return b''


def unpacking(packet):
    # 检查packet是否少于8个字节，这意味着它是无效的
    if len(packet) < 8:
        return None

    # 从前4个字节中提取序列号，使用小端字节顺序
    seq_num = int.from_bytes(packet[0:4], byteorder='little', signed=True)

    # 从下一个4个字节中提取CRC，使用小端字节顺序
    crc_num = int.from_bytes(packet[4:8], byteorder='little', signed=True)

    # 返回序列号、CRC号和数据
    return seq_num, crc_num, packet[8:]


def pack_ack(ack_num):
    # 检查输入类型是否正确
    if not isinstance(ack_num, int):
        raise TypeError('Please provide an integer value for the ACK number.')

    # 使用小端字节顺序将ACK转换为字节
    ack_bytes = ack_num.to_bytes(4, byteorder='little', signed=True)

    # 返回打包后的数据
    return ack_bytes
