import configparser
import time

import UDT
import crc
import packet


def receive(sock, filename, ip_port):
    # 创建UDT对象
    config = configparser.ConfigParser()
    config.read('config.ini')
    lost = config.getfloat('protocol', 'Error_rate') / 100.0
    err = config.getfloat('protocol', 'Lost_rate') / 100.0
    udter = UDT.UDT(lost, err)
    # 打开文件
    file = open(filename, "wb")
    log_filename = f"{ip_port[0]}_{ip_port[1]}_log_file.txt"
    log_file = open(log_filename, "a+")
    # 初始化期望的帧序号
    frame_expected = 0
    # 写日志
    log_message = "{time}: Receiving file: {filename}\n".format(time=time.ctime(), filename=filename)
    log_file.write(log_message)
    # 接收数据直至结束
    while True:
        # 使用UDT对象的recv()方法接收数据
        pdu, addr = udter.recv(sock)
        if not pdu:
            break
        # 提取数据包的序号、校验和和数据
        seq_num, crc_num, data = packet.unpacking(pdu)
        # 校验数据的校验和
        crc_expected = crc.calculate_crc(data)
        if crc_expected != crc_num:
            # 记录数据出错
            log_message = "{time}: Receive PDU={seq_num}, STATUS=DataErr, FRAME_EXPECTED={frame_expected} from {addr}\n".format(
                time=time.ctime(), seq_num=seq_num, frame_expected=frame_expected, addr=str(addr))
            log_file.write(log_message)
            continue
        # 处理数据如果数据的序号和期望的序号相同
        if seq_num == frame_expected:
            # 记录数据正确并发送ACK
            log_message = "{time}: Receive PDU={seq_num}, STATUS=OK, FRAME_EXPECTED={frame_expected} from {addr}\n".format(
                time=time.ctime(), seq_num=seq_num, frame_expected=frame_expected, addr=str(addr))
            log_file.write(log_message)
            udter.sendack(frame_expected, sock, addr)
            frame_expected += 1
            file.write(data)
        # 如果数据的序号和期望的序号不同，发送上一个ACK
        else:
            log_message = "{time}: Receive PDU={seq_num}, STATUS=NoErr, FRAME_EXPECTED={frame_expected} from {addr}\n".format(
                time=time.ctime(), seq_num=seq_num, frame_expected=frame_expected, addr=str(addr))
            log_file.write(log_message)
            udter.sendack(frame_expected - 1, sock, addr)
    log_message = "{time}: Program execution completed.\n".format(time=time.ctime())
    log_file.write(log_message)
    print("Program execution completed. Check log file for details.")
    # 写日志尾
    log_message = "{time}: Data received successfully.\n".format(time=time.ctime())
    log_file.write(log_message)
    # 关闭日志文件
    log_file.close()
    file.close()
