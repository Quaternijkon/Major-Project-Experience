# coding=utf-8
import random
import time


class UDT:

    def __init__(self, lost, err):
        # 初始化UDT，丢包率为lost，错误率为err
        random.seed(time.time())
        self.LOST_PROB = lost
        self.ERR_PROB = err

    def send(self, packet, sock, addr):
        # 发送数据包packet，如果随机数小于错误率，则给数据包添加错误
        if random.random() < self.ERR_PROB:
            packet = self.make_error(packet)
        # 如果随机数大于丢包率，则发送数据包
        if random.random() > self.LOST_PROB:
            sock.sendto(packet, addr)

    @staticmethod
    def recv(sock):
        # 接收数据包
        packet, addr = sock.recvfrom(1024)
        return packet, addr

    def sendack(self, ack, sock, addr):
        # 将ack转换为字节流，发送ack
        ack_bytes = ack.to_bytes(4, byteorder='little', signed=True)
        if random.random() > self.LOST_PROB:
            sock.sendto(ack_bytes, addr)

    @staticmethod
    def recvack(sock):
        # 接收ack
        ack_bytes, addr = sock.recvfrom(1024)
        ack = int.from_bytes(ack_bytes, byteorder='little', signed=True)
        return ack, addr

    @staticmethod
    def make_error(packet):
        # 给数据包添加错误
        err_data = b''
        for i in range(len(packet) - 8):
            byte = random.randint(65, 121)
            err_data = err_data + byte.to_bytes(1, byteorder='little', signed=True)
        return packet[0:8] + err_data
