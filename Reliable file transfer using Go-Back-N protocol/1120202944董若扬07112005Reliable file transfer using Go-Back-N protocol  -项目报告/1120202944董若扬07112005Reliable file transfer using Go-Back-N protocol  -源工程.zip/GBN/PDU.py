import crc


class PDU:
    def __init__(self, seq_num, data=b''):
        self.seq = seq_num
        self.data = data
        # 计算数据的校验和
        self.crc = crc.calculate_crc(data)
        self.start_time = -1

    def __str__(self):
        # 重写__str__方法，方便打印
        return f"PDU(seq={self.seq}, data={self.data}, crc={self.crc})"
