# old.py

import socket
import threading

import sender
import receiver


def main():
    import re

    while True:
        ip = input("Please input the IP: ")
        if re.match(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", ip):
            break
        else:
            print("Invalid IP address. Please enter a valid IP address.")

    while True:
        try:
            port = int(input("Please input the Port: "))
            if 0 < port <= 65535:
                break
            else:
                print("Invalid port number. Please enter a port number between 1 and 65535.")
        except ValueError:
            print("Invalid port number. Please enter a valid integer.")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ip_port = (ip, port)

    # 绑定socket
    sock.bind(ip_port)
    while True:
        while True:
            option = input("Please input your option: send/receive/close: ")
            if option.lower() not in ["send", "receive", "close"]:
                print("Invalid option. Please enter 'send', 'receive', or 'close'.")
            else:
                break
        if option == "send":
            # 创建锁
            lock = threading.Lock()
            # 获取锁
            lock.acquire()
            import os
            import re

            while True:
                filename = input("Please input the filepath you want to send: ")
                if os.path.isfile(filename):
                    break
                else:
                    print("Invalid file path. Please enter a valid file path.")

            while True:
                receiver_ip = input("Please input the Receiver's IP: ")
                if re.match(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", receiver_ip):
                    break
                else:
                    print("Invalid IP address. Please enter a valid IP address.")

            while True:
                try:
                    receiver_port = int(input("Please input the Receiver's Port: "))
                    if 0 < receiver_port <= 65535:
                        break
                    else:
                        print("Invalid port number. Please enter a port number between 1 and 65535.")
                except ValueError:
                    print("Invalid port number. Please enter a valid integer.")
            # 释放锁
            receiver_ip_port = (receiver_ip, receiver_port)
            lock.release()

            # 创建线程
            send_thread = threading.Thread(target=sender.send, args=(sock, filename, ip_port, receiver_ip_port))
            send_thread.start()
            send_thread.join()

        elif option == "receive":
            # 创建锁
            lock = threading.Lock()
            # 获取锁
            lock.acquire()
            import os

            while True:
                filename = input("Please input the filepath you want to save: ")
                if os.path.isdir(os.path.dirname(os.path.abspath(filename))):
                    break
                else:
                    print("Invalid directory path. Please enter a valid directory path.")
            # 释放锁
            lock.release()
            receive_thread = threading.Thread(target=receiver.receive, args=(sock, filename, ip_port))
            receive_thread.start()
            receive_thread.join()
        elif option == "close":
            sock.close()
            break
        else:
            continue


if __name__ == '__main__':
    main()
