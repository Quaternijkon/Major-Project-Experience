import _thread
import configparser
import threading
import time

import UDT
import timer
import crc
import packet

interval = 1
# 初始化期望的帧序号
ack_expected = 0
# 初始化发送的帧序号
num_packets = 0
# 初始化计时器
send_timer = timer.Timer(interval)
# 初始化日志文件名
log_filename = ""
# 初始化锁
mutex = _thread.allocate_lock()
config = configparser.ConfigParser()
config.read('config.ini')
lost = config.getfloat('protocol', 'Error_rate') / 100.0
err = config.getfloat('protocol', 'Lost_rate') / 100.0

# 创建UDT对象
UDTER = UDT.UDT(lost, err)


def send(sock, filename, ip_port, receiver_addr):
    config = configparser.ConfigParser()
    config.read('config.ini')
    datasize=config.getint('protocol', 'data_length')
    global UDTER
    global mutex
    global ack_expected
    global num_packets
    global send_timer
    global log_filename
    config = configparser.ConfigParser()
    config.read('config.ini')
    log_filename = f"{ip_port[0]}_{ip_port[1]}_log_file.txt"
    # 打开文件
    log_file = open(log_filename, "a+")
    file = open(filename, "rb")
    # 写入日志
    log_file.write(
        "{}:{} send {} to {}:{}".format(ip_port[0], ip_port[1], filename, receiver_addr[0], receiver_addr[1]) + "\n")
    packets = []
    seq_num = 0
    while True:
        # 读取文件
        data = file.read(datasize)
        if not data:
            break
        # 计算校验和
        crc_num = crc.calculate_crc(data)
        # 打包
        pdu = packet.packing(seq_num, crc_num, data)
        # 加入到包列表
        packets.append(pdu)
        seq_num += 1
    num_packets = len(packets)
    log_file.write(f"total {num_packets} packets(512bytes)\n")
    window_size = config.getint('protocol', 'window_size')
    next_frame_to_send = 0

    # 接收函数
    thread = threading.Thread(target=receive, args=(sock,))
    thread.start()
    overtime_flag = 0
    scale = 50
    start = time.perf_counter()
    pre = start
    # 发送窗口
    while ack_expected < len(packets):
        # 互斥锁
        mutex.acquire()
        # 发送窗口
        while next_frame_to_send < ack_expected + window_size:
            # 发送完毕
            if next_frame_to_send >= len(packets):
                break
            # 发送
            if overtime_flag == 0:
                log_file.write(
                    f"{time.ctime()}: Send PDU={next_frame_to_send},STATUS=New,ACKed={ack_expected} to {receiver_addr}\n")
            # 超时
            elif overtime_flag == 1:
                log_file.write(
                    f"{time.ctime()}: Send PDU={next_frame_to_send},STATUS=TO,ACKed={ack_expected} to {receiver_addr}\n")
            # 发送
            send_timer.satrt(next_frame_to_send)
            UDTER.send(packets[next_frame_to_send], sock, receiver_addr)
            next_frame_to_send += 1
        overtime_flag = 0
        # 超时
        if send_timer.overtime(ack_expected):
            overtime_flag = 1
            next_frame_to_send = ack_expected

        # 进度条
        if time.perf_counter() - pre > 1:
            pre = time.perf_counter()
            param = num_packets // 50
            i = next_frame_to_send // param
            a = '█' * i
            b = '░' * (scale - i)
            c = (i / scale) * 100
            dur = pre - start
            print(f"\rProgress: {a}{b} {c:.1f}% ({next_frame_to_send}/{num_packets}) | Elapsed Time: {dur:.2f}s",
                  end='')
        mutex.release()
    print("\nTask completed successfully!")
    # 发送空包
    UDTER.send(packet.pack_empty(), sock, receiver_addr)
    log_file.write("File sent successfully.\n")
    file.close()
    log_file.close()


def receive(sock):
    global mutex
    global ack_expected
    global num_packets
    # 接收ack
    while True:
        ack, _ = UDTER.recvack(sock)

        if ack >= ack_expected:
            # 互斥锁
            mutex.acquire()
            ack_expected = ack + 1
            mutex.release()
        if ack_expected >= num_packets:
            break
