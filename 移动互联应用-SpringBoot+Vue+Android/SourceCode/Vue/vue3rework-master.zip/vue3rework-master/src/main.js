import { createApp } from "vue";
import { createPinia } from "pinia";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import App from "./App.vue";
import router from "./router";

// Nucleo Icons
import "./assets/css/nucleo-icons.css";
import "./assets/css/nucleo-svg.css";
import Antd from "ant-design-vue";
import "ant-design-vue/dist/antd.css";

import materialKit from "./material-kit";
import axios from "axios";
import "babel-polyfill";

axios.defaults.baseURL = "http://8.130.13.195:12345";
const app = createApp(App);
app.config.globalProperties.$http = axios;
app.use(createPinia());
app.use(router);
app.use(Antd);
app.use(materialKit);
app.use(ElementPlus);
app.mount("#app");
