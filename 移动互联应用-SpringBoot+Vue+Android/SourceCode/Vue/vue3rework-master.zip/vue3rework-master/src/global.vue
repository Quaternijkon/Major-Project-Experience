<!--<template>-->
<!--<p></p>-->
<!--</template>-->

<script type="text/javascript">
import { ref } from "vue";

// eslint-disable-next-line no-unused-vars
const userinfo = ref({
  username: "mxy2233",
  password: "muxinyu1",
  nickname: "dingzhen",
  personalSign: "小马",
  avatarUrl: "",
  myPosts: [],
  myCollections: []
});

const postinfo = ref({
  image: [],
  title: "",
  owner: "",
  content: "",
  id: "",
  date: "",
  reviews: [],
  reviewDetail: []
});

const collectioninfo = ref({
  image: [],
  title: "",
  owner: "",
  content: "",
  id: "",
  date: "",
  reviews: []
});

const mypostinfo = ref({
  image: [],
  title: "",
  owner: "",
  content: "",
  id: "",
  date: "",
  reviews: []
});

const islogin = ref(false);
export default {
  name: "global",
  userinfo,
  islogin,
  postinfo,
  collectioninfo,
  mypostinfo
};
</script>

<!--<style scoped>-->

<!--</style>-->
