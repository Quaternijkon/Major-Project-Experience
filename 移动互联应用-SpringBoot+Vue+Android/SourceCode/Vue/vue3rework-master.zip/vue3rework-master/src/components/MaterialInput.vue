<script setup>
defineEmits(["update:modelValue"]);
defineProps(["modelValue"], {
  id: {
    type: String,
    default: ""
  },
  type: {
    type: String,
    default: "text"
  },
  label: {
    type: [String, Object],
    text: String,
    class: String,
    default: () => ({
      class: ""
    })
  },
  value: {
    type: String,
    default: ""
  },
  placeholder: {
    type: String,
    default: ""
  },
  size: {
    type: String,
    default: "md"
  },
  error: {
    type: Boolean,
    default: false
  },
  success: {
    type: Boolean,
    default: false
  },
  isRequired: {
    type: Boolean,
    default: false
  },
  isDisabled: {
    type: Boolean,
    default: false
  },
  inputClass: {
    type: String,
    default: ""
  },
  icon: {
    type: String,
    default: ""
  }
});

function getClasses(size, success, error) {
  let sizeValue, isValidValue;

  sizeValue = size && `form-control-${size}`;

  if (error) {
    isValidValue = "is-invalid";
  } else if (success) {
    isValidValue = "is-valid";
  } else {
    isValidValue = "";
  }

  return `${sizeValue} ${isValidValue}`;
}
</script>
<template>
  <div class="input-group">
    <label v-if="label" :class="label.class">{{
        typeof label == "string" ? label : label.text
      }}</label>
    <span v-if="icon" class="input-group-text"
    ><i :class="`fa-${icon}`" aria-hidden="true" class="fas"></i
    ></span>
    <input
      :id="id"
      :class="[getClasses(size, success, error), inputClass]"
      :disabled="isDisabled"
      :isRequired="isRequired"
      :placeholder="placeholder"
      :type="type"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value)"
      class="form-control"
    />
  </div>
</template>
