<script setup>
defineProps({
  id: {
    type: String,
    default: ""
  },
  color: {
    type: String,
    default: "dark"
  },
  inputClass: {
    type: String,
    default: ""
  },
  labelClass: {
    type: String,
    default: ""
  },
  checked: {
    type: Boolean,
    default: false
  }
});
</script>
<template>
  <div class="form-check">
    <input
      :id="id"
      :checked="checked"
      :class="`bg-${color} border-${color} ${inputClass}`"
      class="form-check-input"
      type="checkbox"
      value=""
    />
    <label :class="labelClass" :for="id" class="form-check-label">
      <slot />
    </label>
  </div>
</template>
