<script setup>
defineProps({
  image: {
    type: String,
    required: true
  },
  alt: {
    type: String,
    required: true
  },
  size: {
    type: String,
    default: "xxl"
  },
  borderRadius: {
    type: String,
    default: ""
  }
});

function getClasses(size, borderRadius) {
  let sizeValue = size && `avatar-${size}`;
  let borderRadiusValue = borderRadius && `border-radius-${borderRadius}`;

  return `${sizeValue} ${borderRadiusValue}`;
}
</script>
<template>
  <img
    :alt="alt"
    :class="getClasses(size, borderRadius)"
    :src="image"
    class="avatar"
  />
</template>
