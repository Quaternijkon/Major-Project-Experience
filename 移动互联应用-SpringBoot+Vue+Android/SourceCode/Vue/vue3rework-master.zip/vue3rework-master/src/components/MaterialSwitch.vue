<script setup>
defineProps({
  id: {
    type: String,
    required: true
  },
  checked: {
    type: Boolean,
    default: false
  },
  labelClass: {
    type: String,
    default: ""
  }
});
</script>

<template>
  <div class="form-check form-switch">
    <input
      :id="id"
      :checked="checked"
      :name="id"
      class="form-check-input"
      type="checkbox"
    />
    <label :class="labelClass" :for="id" class="form-check-label d-block"
    >
      <slot
      />
    </label>
    <slot v-if="$slots.description" name="description" />
  </div>
</template>
