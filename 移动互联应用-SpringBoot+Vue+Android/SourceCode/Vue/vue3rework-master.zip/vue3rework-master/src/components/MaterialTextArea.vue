<script setup>
defineProps({
  id: {
    type: String,
    default: "message"
  },
  rows: {
    type: Number,
    default: 4
  },
  placeholder: {
    type: String,
    default: ""
  },
  labelClass: {
    type: String,
    default: ""
  }
});
</script>
<template>
  <div class="input-group">
    <label :class="labelClass" :for="id">
      <slot />
    </label>
    <textarea
      :id="id"
      :placeholder="placeholder"
      :rows="rows"
      class="form-control"
      name="message"
    />
  </div>
</template>
