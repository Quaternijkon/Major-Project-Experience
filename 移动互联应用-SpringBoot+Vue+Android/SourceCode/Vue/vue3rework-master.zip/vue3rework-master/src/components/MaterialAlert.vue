<script setup>
defineProps({
  color: {
    type: String,
    default: "success"
  },
  dismissible: {
    type: Boolean,
    default: false
  },
  fontWeight: {
    type: String,
    default: ""
  }
});

function getClasses(color, dismissible, fontWeight) {
  let colorValue, dismissibleValue, fontWeightValue;

  colorValue = color && `alert-${color}`;

  dismissibleValue = dismissible && "alert-dismissible fade show";

  fontWeightValue = fontWeight && `font-weight-${fontWeight}`;

  return `${colorValue} ${dismissibleValue} ${fontWeightValue}`;
}
</script>
<template>
  <div
    :class="getClasses(color, dismissible, fontWeight)"
    class="alert text-white"
    role="alert"
  >
    &nbsp;
    <slot />
    <button
      v-if="dismissible"
      aria-label="Close"
      class="btn-close text-lg py-3 opacity-10"
      data-bs-dismiss="alert"
      type="button"
    >
      <span aria-hidden="true" class="text-lg font-weight-bold">&times;</span>
    </button>
  </div>
</template>
