<script setup>
defineProps({
  route: {
    type: String,
    required: true
  },
  color: {
    type: String,
    required: true
  },
  component: {
    type: String,
    required: true
  },
  label: {
    type: String,
    default: ""
  }
});
</script>
<template>
  <a :class="`btn-${color}`" :href="route" class="btn me-2" target="_blank">
    <i
      :class="`fa-${component} ${
        $attrs.class == 'btn-icon-only' ? 'me-0' : 'me-1'
      }`"
      class="fab"
    ></i>
    {{ label }}
  </a>
</template>
