<script setup>
defineProps({
  label: {
    type: String,
    default: ""
  },
  active: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  },
  prev: {
    type: Boolean,
    default: false
  },
  next: {
    type: Boolean,
    default: false
  }
});

function getClasses(active, disabled) {
  let activeValue, disabledValue;

  activeValue = active && "active";
  disabledValue = disabled && "disabled";

  return `${activeValue} ${disabledValue}`;
}
</script>
<template>
  <li :class="getClasses(active, disabled)" class="page-item">
    <a class="page-link" href="javascript:">
      <span :class="active ? 'text-white' : ''" aria-hidden="true">
        {{ prev || next ? null : label }}
        <i v-if="prev" class="fa fa-angle-double-left"></i>
        <i v-if="next" class="fa fa-angle-double-right"></i>
      </span>
    </a>
  </li>
</template>
