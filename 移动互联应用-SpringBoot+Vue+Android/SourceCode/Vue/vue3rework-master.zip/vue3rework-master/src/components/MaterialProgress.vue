<script setup>
defineProps({
  variant: {
    type: String,
    validator: (v) => ["contained", "gradient"].includes(v),
    default: "contained"
  },
  color: {
    type: String,
    validator(color) {
      return [
        "primary",
        "secondary",
        "info",
        "success",
        "warning",
        "danger",
        "error",
        "light",
        "dark"
      ].includes(color);
    },
    default: "success"
  },
  value: {
    type: Number,
    required: true
  }
});

const getColor = (color, variant) => {
  let colorValue;

  if (variant === "gradient") {
    colorValue = `bg-gradient-${color}`;
  } else if (variant === "contained") {
    colorValue = `bg-${color}`;
  } else if (variant === "striped") {
    colorValue = `progress-bar-striped bg-${color}`;
  }

  return colorValue;
};
</script>
<template>
  <div class="progress">
    <div
      :aria-valuenow="value"
      :class="getColor(color, variant)"
      :style="{ width: `${value}%` }"
      aria-valuemax="100"
      aria-valuemin="0"
      class="progress-bar"
      role="progressbar"
    ></div>
  </div>
</template>
