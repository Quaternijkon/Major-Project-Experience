<script setup>
import { onMounted, onUnmounted } from "vue";

//example components
import DefaultNavbar from "../../../examples/navbars/NavbarDefault.vue";
import DefaultFooter from "../../../examples/footers/FooterDefault.vue";

//image
import bg0 from "@/assets/img/bit4.jpg";

//dep
import Typed from "typed.js";

//sections
// import Information from "./Sections/AboutInformation.vue";
// import AboutTeam from "./Sections/AboutTeam.vue";
// import Featuring from "./Sections/AboutFeaturing.vue";
// import Newsletter from "./Sections/AboutNewsletter.vue";
import PresentationExample from "@/views/Presentation/Sections/PresentationExample.vue";
import global from "@/global.vue";

const body = document.getElementsByTagName("body")[0];
//hooks
onMounted(() => {
  body.classList.add("about-us");
  body.classList.add("bg-gray-200");

  if (document.getElementById("typed")) {
    // eslint-disable-next-line no-unused-vars
    var typed = new Typed("#typed", {
      stringsElement: "#typed-strings",
      typeSpeed: 90,
      backSpeed: 90,
      backDelay: 200,
      startDelay: 500,
      loop: true
    });
  }
});

onUnmounted(() => {
  body.classList.remove("about-us");
  body.classList.remove("bg-gray-200");
});
</script>

<script>
import axios from "axios";

export default {
  data() {
    return {
      posts: []
    };
  },

  name: "HelloWorld",
  props: {
    msg: String
  },
  methods: {
    query() {
      axios
        .post("/user/query", {
          username: "mxy2233",
          password: "?"
        })
        .then((response) => {
          const userResponse = response.data;
          if (userResponse.success) {
            console.log("用户名: " + userResponse.user.username + ", 密码: ", userResponse.user.password);
          }
        })
        .catch((error) => {
          console.log(error);
          this.message = error;
        });
    },
    addPost() {
      const title = document.getElementById("title").value;
      const content = document.getElementById("content").value;
      const images = document.getElementById("images").files;
      const formData = new FormData();
      formData.append("title", title);
      formData.append("content", content);
      formData.append("owner", "mxy2233");
      formData.append("id", Math.random().toString(36).substring(2));
      Array.from(images).forEach(image => {
        formData.append("images", image);
      });
      axios.post("/post/add", formData).then((response) => {
        console.log(response);
        alert("发帖成功");
      }).catch((error) => {
        console.log(error);
        alert("发帖失败");
      });
    },

    formatPost(post) {
      // try {
      //   return {
      //     image: post.images[0],
      //     title: post.title,
      //     subtitle: "",
      //     route: "",
      //     pro: true
      //   };
      // } catch (e) {
      //   return {
      //     image: "default_image_url",
      //     title: post.title,
      //     subtitle: "",
      //     route: "",
      //     pro: true
      //   };
      // }
      try {
        return {
          image: post.images.length > 0 ? post.images : ["http://8.130.13.195:8086/home/nginx_root/assembled_server/server/post_images/lJb1ojRNmDN40u6Lt4KyEMpryJFRYZ5lOFPX9O/1672412646371_2345%E6%88%AA%E5%9B%BE202212302300212220121881812113471png"],
          title: post.title,
          owner: post.owner,
          route: "detail-basic",
          pro: false,
          content: post.content,
          id: post.id,
          date: post.date,
          reviews: post.reviews
        };
      } catch (e) {
        return {
          image: post.images.length > 0 ? post.images : ["http://8.130.13.195:8086/home/nginx_root/assembled_server/server/post_images/lJb1ojRNmDN40u6Lt4KyEMpryJFRYZ5lOFPX9O/1672412646371_2345%E6%88%AA%E5%9B%BE202212302300212220121881812113471png"],
          title: post.title,
          owner: post.owner,
          route: "detail-basic",
          pro: false,
          content: post.content,
          id: post.id,
          date: post.date,
          reviews: ["NMSL"]
        };
      }
    },

    getPostList() {
      axios.get("/postList/get").then(response => {
        var postIds = response.data.postIds;
        postIds.forEach(postId => {
          axios.get(`/post/query/${postId}`).then(resp => {
            var convertedPost = this.formatPost(resp.data.post);
            this.posts.push(convertedPost);
          }).catch(e => {
            console.log(e);
          });
        });
      }).catch((error) => {
        console.log(error);
      });
    },

    getCollections(username) {
      this.posts = [];
      axios.get(`/userInfo/query/${username}`).then(response => {
        console.log(response);
        const userInfoResponse = response.data;
        const postList = userInfoResponse.userInfo.myPosts;
        postList.forEach(id => {
          axios.get(`/post/query/${id}`).then(resp => {
            this.posts.push(this.formatPost(resp.data.post));
          }).catch(e => {
            console.log(e);
          });
        });
      }).catch(error => {
        console.log(error);
      });
    }
  }
};
</script>
<template>
  <DefaultNavbar
    :action="{
      route: 'javascript:;',
      label: 'NMSL',
      color: 'btn-white',
    }"
    transparent
  />
  <header class="bg-gradient-dark">
    <div
      :style="{ backgroundImage: `url(${bg0})` }"
      class="page-header min-vh-75"
    >
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8 text-center mx-auto my-auto">
            <h1 class="text-white">
              北京理工大学校园论坛<span
              id="typed"
              class="text-white"
            ></span>
            </h1>
            <div id="typed-strings">
              <h1>我的帖子</h1>
              <h1>疯狂灌水</h1>
              <h1>垃圾倾倒</h1>
            </div>
            <!--            <p class="lead mb-4 text-white opacity-8">-->
            <!--              We’re constantly trying to express ourselves and actualize our-->
            <!--              dreams. If you have the opportunity to play this game-->
            <!--            </p>-->
            <!--            <button class="btn bg-white text-dark" type="submit">-->
            <!--              Create Account-->
            <!--            </button>-->
            <!--            <h6 class="text-white mb-2 mt-5">Find us on</h6>-->
            <!--            <div class="d-flex justify-content-center">-->
            <!--              <a href="javascript:"-->
            <!--              ><i class="fab fa-facebook text-lg text-white me-4"></i-->
            <!--              ></a>-->
            <!--              <a href="javascript:"-->
            <!--              ><i class="fab fa-instagram text-lg text-white me-4"></i-->
            <!--              ></a>-->
            <!--              <a href="javascript:"-->
            <!--              ><i class="fab fa-twitter text-lg text-white me-4"></i-->
            <!--              ></a>-->
            <!--              <a href="javascript:"-->
            <!--              ><i class="fab fa-google-plus text-lg text-white"></i-->
            <!--              ></a>-->
            <!--            </div>-->
          </div>
        </div>
      </div>
    </div>
  </header>
  <div class="card card-body shadow-xl mx-3 mx-md-4 mt-n6">
    <!--    <Information />-->
    <!--    <AboutTeam />-->
    <!--    <Featuring />-->
    <!--    <Newsletter />-->
    <!--    <button type="button" id="post" @click="getCollections(global.userinfo.value.username)">获取帖子</button>-->
    <el-backtop :bottom="100" :right="100" />
    <PresentationExample :data="posts" :description="'别往这倒垃圾'" :heading="'我的帖子'" />
  </div>
  <el-affix :offset="720" position="bottom">
    <el-button type="primary" @click="getCollections(global.userinfo.value.username)">获取帖子</el-button>
  </el-affix>
  <DefaultFooter />
</template>
