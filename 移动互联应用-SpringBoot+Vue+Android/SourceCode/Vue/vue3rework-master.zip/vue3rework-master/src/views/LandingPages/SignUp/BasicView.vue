<script setup>
import { onMounted, ref } from "vue";

// example components
import DefaultNavbar from "@/examples/navbars/NavbarDefault.vue";
import Header from "@/examples/Header.vue";

//Vue Material Kit 2 components
import MaterialInput from "@/components/MaterialInput.vue";
import MaterialSwitch from "@/components/MaterialSwitch.vue";
import MaterialButton from "@/components/MaterialButton.vue";

// material-input
import setMaterialInput from "@/assets/js/material-input";
import axios from "axios";
import router from "@/router";
import { ElMessage } from "element-plus";
import bg0 from "@/assets/img/bit7.jpg";

onMounted(() => {
  setMaterialInput();
});

function onLoginButtonClick() {
  console.log(email.value + password.value);
  axios.post("/user/query", {
    username: email.value,
    password: password.value
  })
    .then((response) => {
      // window.alert(email.value + password.value);
      const userResponse = response.data;
      if (userResponse.success) {
        ElMessage.error("用户名已存在");
      } else {
        axios.post("/user/add", {
          username: email.value,
          password: password.value
        })
          .then((response) => {
            const userResponse = response.data;
            if (userResponse.success) {
              ElMessage.success("注册成功");
              router.push({ path: "/" });
            } else {
              ElMessage.error("注册失败");
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    })
    .catch((error) => {
      console.log(error);
    });
}

const email = ref("");
const password = ref("");
</script>
<template>
  <DefaultNavbar transparent />
  <Header>
    <div
      :style="{
        backgroundImage:
          `url(${bg0})`,
      }"
      class="page-header align-items-start min-vh-100"
      loading="lazy"
    >
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-4 col-md-8 col-12 mx-auto">
            <div class="card z-index-0 fadeIn3 fadeInBottom">
              <div
                class="card-header p-0 position-relative mt-n4 mx-3 z-index-2"
              >
                <div
                  class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1"
                >
                  <h4
                    class="text-white font-weight-bolder text-center mt-2 mb-0"
                  >
                    等你发现更多精彩内容
                  </h4>
                  <!--                  <div class="row mt-3">-->
                  <!--                    <div class="col-2 text-center ms-auto">-->
                  <!--                      <a class="btn btn-link px-3" href="javascript:">-->
                  <!--                        <i class="fa fa-facebook text-white text-lg"></i>-->
                  <!--                      </a>-->
                  <!--                    </div>-->
                  <!--                    <div class="col-2 text-center px-1">-->
                  <!--                      <a class="btn btn-link px-3" href="javascript:">-->
                  <!--                        <i class="fa fa-github text-white text-lg"></i>-->
                  <!--                      </a>-->
                  <!--                    </div>-->
                  <!--                    <div class="col-2 text-center me-auto">-->
                  <!--                      <a class="btn btn-link px-3" href="javascript:">-->
                  <!--                        <i class="fa fa-google text-white text-lg"></i>-->
                  <!--                      </a>-->
                  <!--                    </div>-->
                  <!--                  </div>-->
                </div>
              </div>
              <div class="card-body">
                <form class="text-start" role="form">
                  <MaterialInput
                    id="email"
                    v-model="email"
                    :label="{ text: '账号', class: 'form-label' }"
                    class="input-group-outline my-3"
                    type="email"

                  />
                  <MaterialInput
                    id="password"
                    v-model="password"
                    :label="{ text: '密码', class: 'form-label' }"
                    class="input-group-outline mb-3"
                    type="password"
                  />
                  <MaterialSwitch
                    id="rememberMe"
                    checked
                    class="d-flex align-items-center mb-3"
                    labelClass="mb-0 ms-3"
                  >马上登录
                  </MaterialSwitch>
                  <div class="text-center">
                    <MaterialButton
                      class="my-4 mb-2"
                      color="success"
                      fullWidth
                      type="button"
                      variant="gradient"
                      @click="onLoginButtonClick"
                    >注册
                    </MaterialButton>
                  </div>
                  <p class="mt-4 text-sm text-center">
                    已经拥有一个账号？
                    <a
                      class="text-success text-gradient font-weight-bold"
                      href="/pages/landing-pages/basic"
                    >登录</a
                    >
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--      <footer class="footer position-absolute bottom-2 py-2 w-100">-->
      <!--        <div class="container">-->
      <!--          <div class="row align-items-center justify-content-lg-between">-->
      <!--            <div class="col-12 col-md-6 my-auto">-->
      <!--              <div-->
      <!--                class="copyright text-center text-sm text-white text-lg-start"-->
      <!--              >-->
      <!--                © {{ new Date().getFullYear() }}, made with-->
      <!--                <i aria-hidden="true" class="fa fa-heart"></i> by-->
      <!--                <a-->
      <!--                  class="font-weight-bold text-white"-->
      <!--                  href="https://www.creative-tim.com"-->
      <!--                  target="_blank"-->
      <!--                  >Creative Tim</a-->
      <!--                >-->
      <!--                for a better web.-->
      <!--              </div>-->
      <!--            </div>-->
      <!--            <div class="col-12 col-md-6">-->
      <!--              <ul-->
      <!--                class="nav nav-footer justify-content-center justify-content-lg-end"-->
      <!--              >-->
      <!--                <li class="nav-item">-->
      <!--                  <a-->
      <!--                    class="nav-link text-white"-->
      <!--                    href="https://www.creative-tim.com"-->
      <!--                    target="_blank"-->
      <!--                    >Creative Tim</a-->
      <!--                  >-->
      <!--                </li>-->
      <!--                <li class="nav-item">-->
      <!--                  <a-->
      <!--                    class="nav-link text-white"-->
      <!--                    href="https://www.creative-tim.com/presentation"-->
      <!--                    target="_blank"-->
      <!--                    >About Us</a-->
      <!--                  >-->
      <!--                </li>-->
      <!--                <li class="nav-item">-->
      <!--                  <a-->
      <!--                    class="nav-link text-white"-->
      <!--                    href="https://www.creative-tim.com/blog"-->
      <!--                    target="_blank"-->
      <!--                    >Blog</a-->
      <!--                  >-->
      <!--                </li>-->
      <!--                <li class="nav-item">-->
      <!--                  <a-->
      <!--                    class="nav-link pe-0 text-white"-->
      <!--                    href="https://www.creative-tim.com/license"-->
      <!--                    target="_blank"-->
      <!--                    >License</a-->
      <!--                  >-->
      <!--                </li>-->
      <!--              </ul>-->
      <!--            </div>-->
      <!--          </div>-->
      <!--        </div>-->
      <!--      </footer>-->
    </div>
  </Header>
</template>
