<script setup>
import { onMounted, ref } from "vue";

// example components
import DefaultNavbar from "@/examples/navbars/NavbarDefault.vue";
import Header from "@/examples/Header.vue";

//Vue Material Kit 2 components
import MaterialInput from "@/components/MaterialInput.vue";
import MaterialButton from "@/components/MaterialButton.vue";

// material-input
import setMaterialInput from "@/assets/js/material-input";
import axios from "axios";
import router from "@/router";
import { ElMessage } from "element-plus";
import global from "@/global.vue";
import bg0 from "@/assets/img/bit8.jpg";

onMounted(() => {
  setMaterialInput();
});

function onPostButtonClick() {
  console.log(title.value + content.value);
  const images = document.getElementById("images").files;
  const formData = new FormData();
  formData.append("title", title.value);
  formData.append("content", content.value);
  formData.append("owner", global.userinfo.value.username);
  formData.append("id", Math.random().toString(36).substring(2));
  Array.from(images).forEach((image) => {
    formData.append("images", image);
  });
  axios
    .post("/post/add", formData)
    .then((response) => {
      const postResponse = response.data;
      if (postResponse.success) {
        ElMessage.success("发布成功");
        router.push({ path: "/" });
      } else {
        ElMessage.error("发布失败");
      }
    })
    .catch((error) => {
      console.log(error);
    });
}

const title = ref("");
const content = ref("");
</script>
<template>
  <DefaultNavbar transparent />
  <Header>
    <div
      :style="{
        backgroundImage:
          `url(${bg0})`,
      }"
      class="page-header align-items-start min-vh-100"
      loading="lazy"
    >
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-4 col-md-8 col-12 mx-auto">
            <div class="card z-index-0 fadeIn3 fadeInBottom">
              <div
                class="card-header p-0 position-relative mt-n4 mx-3 z-index-2"
              >
                <div
                  class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1"
                >
                  <h4
                    class="text-white font-weight-bolder text-center mt-2 mb-0"
                  >
                    分享你的精彩
                  </h4>
                </div>
              </div>
              <div class="card-body">
                <form class="text-start" role="form">
                  <MaterialInput
                    id="email"
                    v-model="title"
                    :label="{ text: '标题', class: 'form-label' }"
                    :value="title"
                    class="input-group-outline my-3"
                    type="text"
                  />
                  <MaterialInput
                    id="password"
                    v-model="content"
                    :label="{ text: '内容', class: 'form-label' }"
                    :value="content"
                    class="input-group-outline mb-3"
                    type="text"
                  />
                  <!--                  <MaterialSwitch-->
                  <!--                    id="rememberMe"-->
                  <!--                    checked-->
                  <!--                    class="d-flex align-items-center mb-3"-->
                  <!--                    labelClass="mb-0 ms-3"-->
                  <!--                    >马上登录-->
                  <!--                  </MaterialSwitch>-->
                  <input id="images" multiple name="帖子图片" type="file">

                  <div class="text-center">
                    <MaterialButton
                      class="my-4 mb-2"
                      color="success"
                      fullWidth
                      type="button"
                      variant="gradient"
                      @click="onPostButtonClick"
                    >发布
                    </MaterialButton>
                  </div>
                  <!--                  <p class="mt-4 text-sm text-center">-->
                  <!--                    已经拥有一个账号？-->
                  <!--                    <a-->
                  <!--                      class="text-success text-gradient font-weight-bold"-->
                  <!--                      href="/pages/landing-pages/basic"-->
                  <!--                      >登录</a-->
                  <!--                    >-->
                  <!--                  </p>-->
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Header>
</template>
