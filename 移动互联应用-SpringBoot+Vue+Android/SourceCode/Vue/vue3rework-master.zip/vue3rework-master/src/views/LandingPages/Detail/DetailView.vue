<script setup>
import { onMounted } from "vue";

//Vue Material Kit 2 components
// image
// import profilePic from "@/assets/img/bruce-mars.jpg";
// material-input
import setMaterialInput from "@/assets/js/material-input";
import DefaultNavbar from "../../../examples/navbars/NavbarDefault.vue";
import DefaultFooter from "../../../examples/footers/FooterDefault.vue";
import global from "@/global.vue";

onMounted(() => {
  setMaterialInput();
});
</script>
<!--<script>-->
<!--import axios from "axios";-->
<!--export default {-->
<!--  data() {-->
<!--    return {-->
<!--      review: []-->
<!--    };-->
<!--  },-->
<!--  methods:{-->
<!--    getReviewFromId(reviewId) {-->
<!--      axios.get(`/review/query/${reviewId}`).then(response => {-->
<!--        //这个review就是对应的评论-->
<!--        const review = response.data.review;-->
<!--        this.review.push(review);-->
<!--      }).catch(error => {-->
<!--        console.log(error);-->
<!--      });-->
<!--    }-->
<!--  }-->
<!--}-->

<!--</script>-->
<template>
  <!--  <h1>-->
  <!--    {{ global.postinfo.value.title }}-->
  <!--  </h1>-->
  <!--  <p>-->
  <!--    {{ global.postinfo.value.owner }}-->
  <!--  </p>-->
  <!--  <p>-->
  <!--    {{ global.postinfo.value.content }}-->
  <!--  </p>-->
  <DefaultNavbar transparent />
  <Header>
    <div
      :style="{ backgroundImage: `url(${global.postinfo.value.image[0]})` }"
      class="page-header min-height-400"
      loading="lazy"
    >
      <span class="mask bg-gradient-dark opacity-8"></span>
    </div>
  </Header>
  <div class="card card-body blur shadow-blur mx-3 mx-md-4 mt-n6 mb-4">
    <section class="py-sm-7 py-5 position-relative">
      <div class="container">
        <div class="row">
          <div class="col-12 mx-auto">
            <!--            <div class="mt-n8 mt-md-n9 text-center">-->
            <!--              <div class="blur-shadow-avatar">-->
            <!--                <MaterialAvatar-->
            <!--                  :image="global.userinfo.value.avatarUrl"-->
            <!--                  alt="Avatar"-->
            <!--                  class="shadow-xl position-relative z-index-2"-->
            <!--                  size="xxl"-->
            <!--                />-->
            <!--              </div>-->
            <!--              <p>@{{ global.postinfo.value.title }}</p>-->
            <!--              <div class="col-3 mx-auto">-->
            <!--                <RouterLink-->
            <!--                  :to="{ name: 'presentation' }"-->
            <!--                  class="btn btn-sm bg-gradient-success mb-0 ms-auto d-lg-none d-block"-->
            <!--                >-->
            <!--                  <span>退出</span>-->
            <!--                </RouterLink>-->

            <!--              </div>-->
            <!--            </div>-->
            <div class="row py-7">
              <div
                class="col-lg-7 col-md-7 z-index-2 position-relative px-md-2 px-sm-5 mx-auto"
              >
                <div
                  class="d-flex justify-content-between align-items-center mb-2"
                >
                  <h3 class="mb-0">{{ global.postinfo.value.title }}</h3>
                  <!--                  <p class="mb-0">@{{ global.postinfo.value.owner }}</p>-->
                  <p class="text-secondary text-sm font-weight-normal">
                    @{{ global.postinfo.value.owner }}
                    <br />
                    {{ global.postinfo.value.date }}
                  </p>
                  <!--                  <MaterialButton-->
                  <!--                    class="my-2 mb-2 m-n1"-->
                  <!--                    color="success"-->
                  <!--                    variant="gradient"-->
                  <!--                  ><RouterLink-->
                  <!--                    :to="{ name: 'profile-basic' }"-->
                  <!--                    class="btn btn-sm bg-gradient-success mb-0 ms-auto d-lg-none d-block"-->
                  <!--                  >-->
                  <!--                    <span>编辑</span>-->
                  <!--                  </RouterLink>-->
                  <!--                  </MaterialButton>-->
                </div>
                <div class="row mb-4">
                  <p class="mb-0">{{ global.postinfo.value.content }}</p>
                </div>
                <div
                  v-for="(img, index) in global.postinfo.value.image"
                  :key="index"
                  class="card-header p-0 position-relative"
                >
                  <a class="d-block blur-shadow-image">
                    <img
                      :alt="title"
                      :src="img"
                      class="img-fluid shadow border-radius-lg"
                      loading="lazy"
                    />
                  </a>
                </div>
                <div>
                  <h3 class="mb-0">评论</h3>
                </div>
                <div
                  v-for="(review, index) in global.postinfo.value.reviewDetail"
                  :key="index"
                  class="col-9 mx-auto my-auto"
                >
                  <div class="card card-blog card-background cursor-pointer">
                    <div
                      :style="{ backgroundImage: `url(${review.images[0]})` }"
                      class="full-background"
                      loading="lazy"
                    ></div>
                    <div class="card-body">
                      <div class="content-left text-start my-auto py-4">
                        <h2 class="card-title text-white">
                          @{{ review.username }}
                        </h2>
                        <p class="card-description text-white">
                          {{ review.content }}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <!--                <div class="row mb-4">-->
                <!--                  <div class="col-auto">-->
                <!--                    <span class="h6 me-1">323</span>-->
                <!--                    <span>Posts</span>-->
                <!--                  </div>-->
                <!--                  <div class="col-auto">-->
                <!--                    <span class="h6 me-1">3.5k</span>-->
                <!--                    <span>Followers</span>-->
                <!--                  </div>-->
                <!--                  <div class="col-auto">-->
                <!--                    <span class="h6 me-1">260</span>-->
                <!--                    <span>Following</span>-->
                <!--                  </div>-->
                <!--                </div>-->
                <!--              <div class="row mb-4">-->
                <!--                <p class="mb-0">从理塘到上海，哥收获好多money</p>-->
                <!--              </div>-->
                <!--              <p class="text-lg mb-0">-->
                <!--                Decisions: If you can’t decide, the answer is no. If two equally-->
                <!--                difficult paths, choose the one more painful in the short term-->
                <!--                (pain avoidance is creating an illusion of equality). Choose the-->
                <!--                path that leaves you more equanimous.-->
                <!--                <br /><a-->
                <!--                class="text-success icon-move-right"-->
                <!--                href="javascript:"-->
                <!--              >More about me-->
                <!--                <i class="fas fa-arrow-right text-sm ms-1"></i>-->
                <!--              </a>-->
                <!--              </p>-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <DefaultFooter />
</template>
