<script setup>
// example component
import DefaultCounterCard from "../../../../examples/cards/counterCards/DefaultCounterCard.vue";</script>
<template>
  <section id="count-stats" class="pt-4 pb-6">
    <div class="container">
      <div class="row mb-7">
        <div class="col-lg-2 col-md-4 col-6 mb-4">
          <img
            alt="logo"
            class="w-100 opacity-7"
            src="@/assets/img/logos/gray-logos/logo-coinbase.svg"
          />
        </div>
        <div class="col-lg-2 col-md-4 col-6 mb-4">
          <img
            alt="logo"
            class="w-100 opacity-7"
            src="@/assets/img/logos/gray-logos/logo-nasa.svg"
          />
        </div>
        <div class="col-lg-2 col-md-4 col-6 mb-4">
          <img
            alt="logo"
            class="w-100 opacity-7"
            src="@/assets/img/logos/gray-logos/logo-netflix.svg"
          />
        </div>
        <div class="col-lg-2 col-md-4 col-6 mb-4">
          <img
            alt="logo"
            class="w-100 opacity-7"
            src="@/assets/img/logos/gray-logos/logo-pinterest.svg"
          />
        </div>
        <div class="col-lg-2 col-md-4 col-6 mb-4">
          <img
            alt="logo"
            class="w-100 opacity-7"
            src="@/assets/img/logos/gray-logos/logo-spotify.svg"
          />
        </div>
        <div class="col-lg-2 col-md-4 col-6 mb-4">
          <img
            alt="logo"
            class="w-100 opacity-7"
            src="@/assets/img/logos/gray-logos/logo-vodafone.svg"
          />
        </div>
      </div>
      <div class="row justify-content-center text-center">
        <div class="col-md-3">
          <DefaultCounterCard
            :count="5234"
            :duration="3000"
            description="Of “high-performing” level are led by a certified project manager"
            title="Projects"
          />
        </div>
        <div class="col-md-3">
          <DefaultCounterCard
            :count="3400"
            :duration="3000"
            description="That meets quality standards required by our users"
            suffix="+"
            title="Hours"
          />
        </div>
        <div class="col-md-3">
          <DefaultCounterCard
            :count="24"
            :duration="4000"
            description="Actively engage team members that finishes on time"
            suffix="/7"
            title="Support"
          />
        </div>
      </div>
    </div>
  </section>
</template>
