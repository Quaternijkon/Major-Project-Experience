<script setup>
import { onMounted, ref } from "vue";

// example components
import DefaultNavbar from "@/examples/navbars/NavbarDefault.vue";
import Header from "@/examples/Header.vue";

//Vue Material Kit 2 components
import MaterialInput from "@/components/MaterialInput.vue";
import MaterialButton from "@/components/MaterialButton.vue";

// material-input
import setMaterialInput from "@/assets/js/material-input";
import axios from "axios";
import global from "@/global.vue";
import { ElMessage } from "element-plus";
import router from "@/router";
import bg0 from "@/assets/img/bit9.jpg";

const nickname = ref("");
const personalsign = ref("");

function updateProfile() {
  console.log("updateProfile");
  const formData = new FormData();
  const avatar = document.getElementById("images").files[0];
  formData.append("username", global.userinfo.value.username);
  formData.append("nickname", nickname.value);
  formData.append("personalSign", personalsign.value);
  formData.append("avatar", avatar);
  axios
    .post("/userInfo/update", formData)
    .then((response) => {
      // window.alert("修改成功");
      const userInfoResponse = response.data;
      if (userInfoResponse.success) {
        global.userinfo.value.nickname = userInfoResponse.userInfo.nickname;
        global.userinfo.value.personalSign =
          userInfoResponse.userInfo.personalSign;
        global.userinfo.value.avatarUrl = userInfoResponse.userInfo.avatarUrl;
        ElMessage.success("更新成功");
        router.push({ path: "/pages/landing-pages/author" });
      } else {
        ElMessage.error("更新失败");
      }
    })
    .catch((error) => {
      console.log(error);
    });
}

onMounted(() => {
  setMaterialInput();
});
</script>
<template>
  <DefaultNavbar transparent />
  <Header>
    <div
      :style="{
        backgroundImage:
          `url(${bg0})`,
      }"
      class="page-header align-items-start min-vh-100"
      loading="lazy"
    >
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-4 col-md-8 col-12 mx-auto">
            <div class="card z-index-0 fadeIn3 fadeInBottom">
              <div
                class="card-header p-0 position-relative mt-n4 mx-3 z-index-2"
              >
                <div
                  class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1"
                >
                  <h4
                    class="text-white font-weight-bolder text-center mt-2 mb-0"
                  >
                    狠狠地编辑个人资料
                  </h4>
                </div>
              </div>
              <div class="card-body">
                <form class="text-start" role="form">
                  <MaterialInput
                    id="name"
                    v-model="nickname"
                    :label="{ text: '用户名', class: 'form-label' }"
                    class="input-group-outline my-3"
                    type="name"
                  />
                  <MaterialInput
                    id="text"
                    v-model="personalsign"
                    :label="{ text: '个性签名', class: 'form-label' }"
                    class="input-group-outline mb-3"
                    type="text"
                  />
                  <input id="images" multiple name="帖子图片" type="file">
                  <!--                  <input v-model="nickname" />-->
                  <!--                  <input v-model="personalsign" />-->
                  <div class="text-center">
                    <MaterialButton
                      class="my-4 mb-2"
                      color="success"
                      fullWidth
                      type="button"
                      variant="gradient"
                      @click="updateProfile"
                    >保存
                    </MaterialButton>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Header>
</template>
