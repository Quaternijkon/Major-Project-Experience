<script setup>
import RotatingCard from "../../../examples/cards/rotatingCards/RotatingCard.vue";
import RotatingCardFront from "../../../examples/cards/rotatingCards/RotatingCardFront.vue";
import RotatingCardBack from "../../../examples/cards/rotatingCards/RotatingCardBack.vue";</script>
<template>
  <section class="my-5 py-5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-4 ms-auto me-auto p-lg-4 mt-lg-0 mt-4">
          <RotatingCard>
            <RotatingCardFront
              description="这是碰都不能碰的滑梯"
              icon="touch_app"
              image="https://images.unsplash.com/photo-1569683795645-b62e50fbf103?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80"
              title="给他一点小小的<br /> 北京理工大学震撼"
            />

            <RotatingCardBack
              :action="[
                {
                  route: '/',
                  label: '从大专开始',
                },
              ]"
              description="北京理工大学培养了大量的985学生，被称为985的摇篮。"
              image="https://images.unsplash.com/photo-1498889444388-e67ea62c464b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1365&q=80"
              title="深入了解北京理工大学"
            />
          </RotatingCard>
        </div>
        <!--        <div class="col-lg-6 ms-auto">-->
        <!--          <div class="row justify-content-start">-->
        <!--            <DefaultInfoCard-->
        <!--              description="描述1"-->
        <!--              icon="content_copy"-->
        <!--              title="标题1"-->
        <!--            />-->
        <!--            <DefaultInfoCard-->
        <!--              description="描述2"-->
        <!--              icon="flip_to_front"-->
        <!--              title="标题2"-->
        <!--            />-->
        <!--          </div>-->
        <!--          <div class="row justify-content-start mt-5">-->
        <!--            <DefaultInfoCard-->
        <!--              class="mt-3"-->
        <!--              description="描述3"-->
        <!--              icon="price_change"-->
        <!--              title="标题3"-->
        <!--            />-->
        <!--            <DefaultInfoCard-->
        <!--              class="mt-3"-->
        <!--              description="描述4"-->
        <!--              icon="devices"-->
        <!--              title="标题4"-->
        <!--            />-->
        <!--          </div>-->
        <!--        </div>-->
      </div>
    </div>
  </section>
</template>
