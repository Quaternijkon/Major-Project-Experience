<script setup>
import DefaultCounterCard from "../../../examples/cards/counterCards/DefaultCounterCard.vue";</script>

<template>
  <section id="count-stats" class="pt-3 pb-4">
    <div class="container">
      <div class="row">
        <div class="col-lg-9 z-index-2 border-radius-xl mx-auto py-3">
          <div class="row">
            <div class="col-md-4 position-relative">
              <DefaultCounterCard
                :count="70"
                :duration="3000"
                color="success"
                description=""
                divider="vertical"
                suffix="+"
                title="帖子"
              />
            </div>
            <div class="col-md-4 position-relative">
              <DefaultCounterCard
                :count="15"
                :duration="3000"
                color="success"
                description=""
                divider="vertical"
                suffix="+"
                title="用户"
              />
            </div>
            <div class="col-md-4">
              <DefaultCounterCard
                :count="4"
                :duration="3000"
                color="success"
                description=""
                title="今天在线"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
