<script setup>
import ExampleCard from "../Components/ExampleCard.vue";
import MaterialBadge from "../../../components/MaterialBadge.vue";

// images
import imgSigninCover from "@/assets/img/signin-cover.png";</script>
<template>
  <section class="py-5">
    <div class="container">
      <div class="row">
        <div class="row text-center my-sm-5 mt-5">
          <div class="col-lg-6 mx-auto">
            <MaterialBadge class="mb-3" color="success"
            >北京理工大专
            </MaterialBadge
            >
            <h2 class="">通过我们的帮助</h2>
            <p class="lead">
              最便捷的方式斩获世界一流大专文凭
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="container mt-5">
      <div class="row">
        <div class="col-md-8">
          <div class="row mt-4">
            <!--            <div class="col-md-6 mt-md-0 mt-5">-->
            <!--              <ExampleCard-->
            <!--                class="shadow-lg"-->
            <!--                image="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/material-design-system/presentation/pages/about-us.jpg"-->
            <!--                route="about"-->
            <!--                title="About Us Page"-->
            <!--              />-->
            <!--            </div>-->
            <div class="col-md-6 mt-md-0 mt-5">
              <ExampleCard
                class="shadow-lg"
                image="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/material-design-system/presentation/pages/contact.jpg"
                route="contactus"
                title="Contact Us Page"
              />
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-md-6 mt-md-0 mt-5">
              <ExampleCard
                :image="imgSigninCover"
                classes="mt-5"
                route="signin-basic"
                title="Sign In Page"
              />
            </div>
            <!--            <div class="col-md-6 mt-md-0 mt-5">-->
            <!--              <ExampleCard-->
            <!--                classes="shadow-lg"-->
            <!--                image="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/material-design-system/presentation/pages/author.jpg"-->
            <!--                route="author"-->
            <!--                title="Author Page"-->
            <!--              />-->
            <!--            </div>-->
          </div>
        </div>
        <!--        <div class="col-md-3 mx-auto mt-md-0 mt-3">-->
        <!--          <div class="position-sticky" style="top: 100px !important">-->
        <!--            <h3>-->
        <!--              Presentation Pages for Company, Landing Pages, Blogs and Support-->
        <!--            </h3>-->
        <!--            <h6 class="text-secondary font-weight-normal">-->
        <!--              These is just a small selection of the multiple possibitilies you-->
        <!--              have. Focus on the business, not on the design.-->
        <!--            </h6>-->
        <!--          </div>-->
        <!--        </div>-->
      </div>
    </div>
  </section>
</template>
