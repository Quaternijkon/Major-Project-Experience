<script setup>
import ExampleCard from "../Components/ExampleCard.vue";
import global from "@/global.vue";
import axios from "axios";
// import MaterialBadge from "../../../components/MaterialBadge.vue";

defineProps({
  data: {
    // image: post.images,
    // title: post.title,
    // owner: post.owner,
    // route: "detail-basic",
    // pro: false,
    // content: post.content,
    // id: post.id,
    // date: post.date,
    // reviews: post.reviews,
    images: {
      type: Array,
      default: []
    },
    title: {
      type: String,
      default: ""
    },
    owner: {
      type: String,
      default: ""
    },
    content: {
      type: String,
      default: ""
    },
    id: {
      type: String,
      default: ""
    },
    date: {
      type: String,
      default: ""
    },
    reviews: {
      type: Array,
      default: []
    }
  },
  // data: {
  //   type: Array,
  //   required: true,
  //   // heading: {
  //   //   type: String,
  //   //   required: true,
  //   // },
  //   // description: {
  //   //   type: String,
  //   //   required: true,
  //   // },
  //   items: {
  //     type: Array,
  //     required: true,
  //     image: {
  //       type: String,
  //       required: true,
  //     },
  //     title: {
  //       type: String,
  //       required: true,
  //     },
  //     subtitle: {
  //       type: String,
  //       required: true,
  //     },
  //   },
  // },
  heading: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  col1: {
    type: String,
    default: "col-lg-3"
  },
  col2: {
    type: String,
    default: "col-lg-9"
  }
});

function getReviewFromId(reviewId) {
  axios
    .get(`/review/query/${reviewId}`)
    .then((response) => {
      //这个review就是对应的评论
      const review = response.data.review;
      global.postinfo.value.reviewDetail.push(review);
      // this.review.push(review);
    })
    .catch((error) => {
      console.log(error);
    });
}
</script>
<script>
export default {
  inheritAttrs: false
};
</script>
<template>
  <section class="my-5 py-5">
    <div class="container mt-sm-5 mt-3">
      <div :class="`${col1 ?? 'col-lg-3'}`">
        <div
          class="position-sticky pb-lg-5 pb-3 mt-lg-0 mt-5 ps-2"
          style="top: 100px"
        >
          <h3>{{ heading }}</h3>
          <h6 class="text-secondary font-weight-normal pe-3">
            {{ description }}
          </h6>
        </div>
      </div>

      <div :class="`${col2 ?? 'col-lg-9'}`">
        <div :class="`row ${index != 0 ? 'mt-3' : ''}`">
          <div
            v-for="{
              image,title,owner,route,pro,content,id,date,reviews,
            } in data"
            :key="title"
            class="col-md-4 mt-md-0"
          >
            <ExampleCard
              :date="date"
              :image="image[0]"
              :owner="owner"
              :pro="pro"
              :route="route"
              :title="title"
              class="min-height-160 shadow-lg mt-4"
              @click="
                () => {
                  global.postinfo.value.image = image;
                  global.postinfo.value.title = title;
                  global.postinfo.value.owner = owner;
                  global.postinfo.value.content = content;
                  global.postinfo.value.id = id;
                  global.postinfo.value.date = date;
                  global.postinfo.value.reviews = reviews;
                  global.postinfo.value.reviewDetail = [];
                  reviews.forEach((reviewId) => {
                    getReviewFromId(reviewId);
                  });
                }
              "
            />
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--  <p>-->
  <!--    {{data}}-->
  <!--  </p>-->
</template>
