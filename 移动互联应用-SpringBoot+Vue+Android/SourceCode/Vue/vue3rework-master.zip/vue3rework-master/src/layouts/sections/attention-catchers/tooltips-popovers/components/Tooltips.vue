<script setup>
import { onMounted } from "vue";
//Vue Material Kit 2 components
import MaterialButton from "@/components/MaterialButton.vue";

// popover
import setTooltip from "@/assets/js/tooltip";

// store
import { useAppStore } from "@/stores";

const store = useAppStore();

// hook
onMounted(() => {
  setTooltip(store.bootstrap);
});
</script>
<template>
  <div class="container">
    <div class="row py-8 text-center">
      <div>
        <MaterialButton
          color="success"
          data-bs-placement="top"
          data-bs-toggle="tooltip"
          title="Tooltip on top"
          variant="gradient"
        >
          Tooltip on top
        </MaterialButton>

        <MaterialButton
          class="mx-2"
          color="success"
          data-bs-placement="right"
          data-bs-toggle="tooltip"
          title="Tooltip on right"
          variant="gradient"
        >
          Tooltip on right
        </MaterialButton>

        <MaterialButton
          color="success"
          data-bs-placement="bottom"
          data-bs-toggle="tooltip"
          title="Tooltip on bottom"
          variant="gradient"
        >
          Tooltip on bottom
        </MaterialButton>

        <MaterialButton
          class="ms-2"
          color="success"
          data-bs-placement="left"
          data-bs-toggle="tooltip"
          title="Tooltip on left"
          variant="gradient"
        >
          Tooltip on left
        </MaterialButton>
      </div>
    </div>
  </div>
</template>
