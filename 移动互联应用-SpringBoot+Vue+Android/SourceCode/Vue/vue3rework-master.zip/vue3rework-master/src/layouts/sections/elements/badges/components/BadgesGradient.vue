<script setup>
//Vue Material Kit 2 components
import MaterialBadge from "@/components/MaterialBadge.vue";</script>
<template>
  <section class="py-7 m-3 bg-gray-100">
    <div class="container">
      <div class="row justify-space-between text-center py-2">
        <div class="col-12">
          <MaterialBadge color="primary" variant="gradient">
            Primary
          </MaterialBadge>

          <MaterialBadge class="mx-1" color="secondary" variant="gradient">
            Secondary
          </MaterialBadge>

          <MaterialBadge color="success" variant="gradient">
            Success
          </MaterialBadge>

          <MaterialBadge class="mx-1" color="danger" variant="gradient">
            Danger
          </MaterialBadge>

          <MaterialBadge color="warning" variant="gradient">
            Warning
          </MaterialBadge>

          <MaterialBadge class="mx-1" color="info" variant="gradient">
            Info
          </MaterialBadge>

          <MaterialBadge class="text-dark" color="light" variant="gradient">
            Light
          </MaterialBadge>

          <MaterialBadge class="ms-1" color="dark" variant="gradient">
            Dark
          </MaterialBadge>
        </div>
      </div>
    </div>
  </section>
</template>
