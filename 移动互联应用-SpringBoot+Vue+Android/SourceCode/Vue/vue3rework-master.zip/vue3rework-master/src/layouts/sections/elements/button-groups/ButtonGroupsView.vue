<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Button Groups page components
import ButtonGroupsSimple from "./components/ButtonGroupsSimple.vue";
import ButtonGroupsOutline from "./components/ButtonGroupsOutline.vue";
import ButtonGroupsCheckbox from "./components/ButtonGroupsCheckbox.vue";
import ButtonGroupsRadio from "./components/ButtonGroupsRadio.vue";
import ButtonGroupsSizing from "./components/ButtonGroupsSizing.vue";

// Button Groups page components codes
import {
  buttonGroupsCheckboxCode,
  buttonGroupsOutlineCode,
  buttonGroupsRadioCode,
  buttonGroupsSimpleCode,
  buttonGroupsSizingCode
} from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[
      { label: 'Elements', route: '#' },
      { label: 'Button Groups' },
    ]"
    title="Button Groups"
  >
    <View
      id="button-groups-simple"
      :code="buttonGroupsSimpleCode"
      title="Button Groups Simple"
    >
      <ButtonGroupsSimple />
    </View>

    <View
      id="button-groups-outline"
      :code="buttonGroupsOutlineCode"
      title="Button Groups Outline"
    >
      <ButtonGroupsOutline />
    </View>

    <View
      id="button-groups-checkbox"
      :code="buttonGroupsCheckboxCode"
      title="Button Groups Checkbox"
    >
      <ButtonGroupsCheckbox />
    </View>

    <View
      id="button-groups-radio"
      :code="buttonGroupsRadioCode"
      title="Button Groups Radio"
    >
      <ButtonGroupsRadio />
    </View>
    <View
      id="button-groups-sizing"
      :code="buttonGroupsSizingCode"
      title="Button Groups Sizing"
    >
      <ButtonGroupsSizing />
    </View>
  </BaseLayout>
</template>
