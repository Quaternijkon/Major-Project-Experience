<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Inputs page components
import InputStatic from "./components/InputStatic.vue";
import InputDynamic from "./components/InputDynamic.vue";
import InputIcon from "./components/InputIcon.vue";
import InputSuccess from "./components/InputSuccess.vue";
import InputError from "./components/InputError.vue";
import InputDisabled from "./components/InputDisabled.vue";

// Inputs page components codes
import {
  inputDisabledCode,
  inputDynamicCode,
  inputErrorCode,
  inputIconCode,
  inputOutlinedCode,
  inputStaticCode,
  inputSuccessCode
} from "./components/codes";

//nav-pills & material-input
import setNavPills from "@/assets/js/nav-pills";
import setMaterialInput from "@/assets/js/material-input";

//hook
onMounted(() => {
  setNavPills();
  setMaterialInput();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Input Areas', route: '#' }, { label: 'Inputs' }]"
    title="Inputs"
  >
    <View id="input-dynamic" :code="inputDynamicCode" title="Input dynamic">
      <InputDynamic />
    </View>

    <View id="input-static" :code="inputStaticCode" title="Input static">
      <InputStatic />
    </View>

    <View id="input-outlined" :code="inputOutlinedCode" title="Input outline">
      <inputOutlined />
    </View>

    <View id="input-with-icon" :code="inputIconCode" title="Input with icon">
      <InputIcon />
    </View>

    <View id="input-success" :code="inputSuccessCode" title="Input success">
      <InputSuccess />
    </View>

    <View id="input-error" :code="inputErrorCode" title="Input error">
      <InputError />
    </View>

    <View id="input-disabled" :code="inputDisabledCode" title="Input disabled">
      <InputDisabled />
    </View>
  </BaseLayout>
</template>
