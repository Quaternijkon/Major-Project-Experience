<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Typography page components
import Roboto from "./components/Roboto.vue";

// Typography page components codes
import { robotoCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Elements', route: '#' }, { label: 'Typography' }]"
    title="Typography"
  >
    <View
      id="typography-roboto"
      :code="robotoCode"
      height="600"
      title="Typography - Font Family Roboto"
    >
      <Roboto />
    </View>
  </BaseLayout>
</template>
