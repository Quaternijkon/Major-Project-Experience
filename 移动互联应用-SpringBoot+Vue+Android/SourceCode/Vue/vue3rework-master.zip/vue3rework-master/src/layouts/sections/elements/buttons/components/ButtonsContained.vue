<script setup>
//Vue Material Kit 2 components
import MaterialButton from "@/components/MaterialButton.vue";</script>
<template>
  <section class="py-7 m-3 bg-gray-100">
    <div class="container">
      <div class="row justify-space-between text-center py-2">
        <div class="col-12 mx-auto">
          <MaterialButton
            class="w-auto me-2"
            color="secondary"
            variant="contained"
          >
            Primary
          </MaterialButton>

          <MaterialButton
            class="w-auto me-2"
            color="primary"
            variant="contained"
          >
            Secondary
          </MaterialButton>

          <MaterialButton class="w-auto me-2" color="info" variant="contained">
            Info
          </MaterialButton>

          <MaterialButton
            class="w-auto me-2"
            color="success"
            variant="contained"
          >
            Success
          </MaterialButton>

          <MaterialButton
            class="w-auto me-2"
            color="warning"
            variant="contained"
          >
            Warning
          </MaterialButton>

          <MaterialButton
            class="w-auto me-2"
            color="danger"
            variant="contained"
          >
            Danger
          </MaterialButton>

          <MaterialButton class="w-auto me-2" color="light" variant="contained">
            Light
          </MaterialButton>

          <MaterialButton class="w-auto me-2" color="dark" variant="contained">
            Dark
          </MaterialButton>
          <MaterialButton class="w-auto me-2" color="white" variant="contained">
            White
          </MaterialButton>
        </div>
      </div>
    </div>
  </section>
</template>
