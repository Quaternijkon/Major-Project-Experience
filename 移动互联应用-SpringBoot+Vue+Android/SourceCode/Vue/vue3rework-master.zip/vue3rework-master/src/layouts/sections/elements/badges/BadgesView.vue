<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Badges page components
import BadgesGradient from "./components/BadgesGradient.vue";
import BadgesSimple from "./components/BadgesSimple.vue";
import BadgesSimpleRounded from "./components/BadgesSimpleRounded.vue";

// Badges page components codes
import { badgesGradientCode, badgesRoundedCode, badgesSimpleCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Elements', route: '#' }, { label: 'Badges' }]"
    title="Badges"
  >
    <View
      id="badges-gradient"
      :code="badgesGradientCode"
      title="Badges Gradients"
    >
      <BadgesGradient />
    </View>

    <View id="badges-simple" :code="badgesSimpleCode" title="Badges Simple">
      <BadgesSimple />
    </View>

    <View
      id="badges-rounded"
      :code="badgesRoundedCode"
      title="Badges Simple Rounded"
    >
      <BadgesSimpleRounded />
    </View>
  </BaseLayout>
</template>
