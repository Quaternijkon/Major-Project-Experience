<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Avatars page components
import AvatarGroup from "./components/AvatarGroup.vue";
import AvatarSize from "./components/AvatarSize.vue";

// Avatars page components codes
import { avatarGroupCode, avatarSizeCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Elements', route: '#' }, { label: 'Avatars' }]"
    title="Avatars"
  >
    <View id="avatar-group" :code="avatarGroupCode" title="Avatar Group">
      <AvatarGroup />
    </View>
    <View id="avatar-size" :code="avatarSizeCode" title="Avatar Size">
      <AvatarSize />
    </View>
  </BaseLayout>
</template>
