<script setup>
import { onMounted } from "vue";
//Vue Material Kit 2 components
import MaterialButton from "@/components/MaterialButton.vue";

// popover
import setPopover from "@/assets/js/popover";

// store
import { useAppStore } from "@/stores";

const store = useAppStore();

// hook
onMounted(() => {
  setPopover(store.bootstrap);
});
</script>
<template>
  <div class="container">
    <div class="row py-7 text-center">
      <div>
        <MaterialButton
          color="success"
          data-bs-container="body"
          data-bs-content="That’s the main thing people are controlled by! Thoughts- their perception of themselves!"
          data-bs-placement="top"
          data-bs-toggle="popover"
          variant="gradient"
        >
          Popover on top
        </MaterialButton>

        <MaterialButton
          class="mx-2"
          color="success"
          data-bs-container="body"
          data-bs-content="We’re not always in the position that we want to be at."
          data-bs-placement="right"
          data-bs-toggle="popover"
          variant="gradient"
        >
          Popover on right
        </MaterialButton>

        <MaterialButton
          color="success"
          data-bs-container="body"
          data-bs-content="A lot of people don’t appreciate the moment until it’s passed."
          data-bs-placement="bottom"
          data-bs-toggle="popover"
          variant="gradient"
        >
          Popover on bottom
        </MaterialButton>

        <MaterialButton
          class="ms-2"
          color="success"
          data-bs-container="body"
          data-bs-content="It really matters and then like it really doesn’t matter. What matters is the people who are sparked by it."
          data-bs-placement="left"
          data-bs-toggle="popover"
          variant="gradient"
        >
          Popover on left
        </MaterialButton>
      </div>
    </div>
  </div>
</template>
