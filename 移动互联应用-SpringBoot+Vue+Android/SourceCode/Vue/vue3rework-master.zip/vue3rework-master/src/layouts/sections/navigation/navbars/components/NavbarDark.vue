<script setup>
import NavbarDefault from "@/examples/navbars/NavbarDefault.vue";</script>
<template>
  <NavbarDefault dark transparent />
</template>
