<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Buttons page components
import ButtonsGradient from "./components/ButtonsGradient.vue";
import ButtonsContained from "./components/ButtonsContained.vue";
import ButtonsOutlined from "./components/ButtonsOutlined.vue";
import ButtonsSizes from "./components/ButtonsSizes.vue";
import ButtonsIconLeft from "./components/ButtonsIconLeft.vue";
import ButtonsIconRight from "./components/ButtonsIconRight.vue";

// Buttons page components codes
import {
  buttonsContainedCode,
  buttonsGradientCode,
  buttonsIconLeftCode,
  buttonsIconRightCode,
  buttonsOutlinedCode,
  buttonsSizesCode
} from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Elements', route: '#' }, { label: 'Buttons' }]"
    title="Buttons"
  >
    <View
      id="button-gradient"
      :code="buttonsGradientCode"
      title="Buttons Colors Gradient"
    >
      <ButtonsGradient />
    </View>

    <View
      id="button-contained"
      :code="buttonsContainedCode"
      title="Buttons Contained"
    >
      <ButtonsContained />
    </View>

    <View
      id="button-outlined"
      :code="buttonsOutlinedCode"
      title="Buttons Outline"
    >
      <ButtonsOutlined />
    </View>

    <View id="button-sizes" :code="buttonsSizesCode" title="Buttons Sizes">
      <ButtonsSizes />
    </View>

    <View
      id="button-icon-left"
      :code="buttonsIconLeftCode"
      title="Buttons Icon Left"
    >
      <ButtonsIconLeft />
    </View>

    <View
      id="button-icon-right"
      :code="buttonsIconRightCode"
      title="Buttons Icon Right"
    >
      <ButtonsIconRight />
    </View>
  </BaseLayout>
</template>
