<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Tooltips And Popovers page components
import Popovers from "./components/Popovers.vue";
import Tooltips from "./components/Tooltips.vue";

// Tooltips And Popovers page components codes
import { popoversCode, tooltipsCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[
      { label: 'Attention Catchers', route: '#' },
      { label: 'Tooltip & Popovers' },
    ]"
    title="Tooltip & Popovers"
  >
    <View id="popovers" :code="popoversCode" title="Popovers">
      <Popovers />
    </View>

    <View id="tooltips" :code="tooltipsCode" title="Tooltips">
      <Tooltips />
    </View>
  </BaseLayout>
</template>
