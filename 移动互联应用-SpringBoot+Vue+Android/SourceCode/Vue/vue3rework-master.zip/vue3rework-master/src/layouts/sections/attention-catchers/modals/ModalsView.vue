<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Modals page components
import SimpleModal from "./components/SimpleModal.vue";

// Modals page components codes
import { simpleModalCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[
      { label: 'Attention Catchers', route: '#' },
      { label: 'Modals' },
    ]"
    title="Modals"
  >
    <View id="simple-modal" :code="simpleModalCode" title="Simple Modal">
      <SimpleModal />
    </View>
  </BaseLayout>
</template>
