<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Dropdowns page components
import DropdownAndDropup from "./components/DropdownAndDropup.vue";

// Dropdowns page components codes
import { dropdownAndDropupCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Elements', route: '#' }, { label: 'Dropdowns' }]"
    title="Dropdowns"
  >
    <View
      id="dropdown-dropup"
      :code="dropdownAndDropupCode"
      title="Dropdown and Dropup"
    >
      <DropdownAndDropup />
    </View>
  </BaseLayout>
</template>
