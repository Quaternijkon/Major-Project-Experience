<script setup>
//Vue Material Kit 2 components
import MaterialProgress from "@/components/MaterialProgress.vue";</script>
<template>
  <section class="py-6 mt-4">
    <div class="container">
      <div class="row justify-space-between py-2">
        <div class="col-lg-6 mx-auto">
          <MaterialProgress :value="50" class="mb-3" color="primary" />
          <MaterialProgress :value="50" class="mb-3" color="secondary" />
          <MaterialProgress :value="50" class="mb-3" color="success" />
          <MaterialProgress :value="50" class="mb-3" color="info" />
          <MaterialProgress :value="50" class="mb-3" color="warning" />
          <MaterialProgress :value="50" class="mb-3" color="danger" />
          <MaterialProgress :value="50" class="mb-3" color="dark" />
        </div>
      </div>
    </div>
  </section>
</template>
