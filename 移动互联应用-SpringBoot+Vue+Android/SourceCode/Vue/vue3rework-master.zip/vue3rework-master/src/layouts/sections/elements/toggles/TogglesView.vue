<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Toggles page components
import Toggle from "./components/Toggle.vue";
import ToggleContext from "./components/ToggleContext.vue";

// Toggles page components codes
import { toggleCode, toggleContextCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[{ label: 'Elements', route: '#' }, { label: 'Toggles' }]"
    title="Toggles"
  >
    <View id="toggle" :code="toggleCode" title="Toggle">
      <Toggle />
    </View>
    <View id="toggle-context" :code="toggleContextCode" title="Toggle Context">
      <ToggleContext />
    </View>
  </BaseLayout>
</template>
