<script setup>
//Vue Material Kit 2 components
import MaterialButton from "@/components/MaterialButton.vue";</script>
<template>
  <section class="py-7 m-3 bg-gray-100">
    <div class="container">
      <div class="row justify-space-between text-center py-2">
        <div class="col-12 mx-auto">
          <MaterialButton
            class="w-auto me-2"
            color="secondary"
            variant="outline"
          >Primary
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="primary" variant="outline"
          >Secondary
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="info" variant="outline"
          >Info
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="success" variant="outline"
          >Success
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="warning" variant="outline"
          >Warning
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="danger" variant="outline"
          >Danger
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="light" variant="outline"
          >Light
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="dark" variant="outline"
          >Dark
          </MaterialButton
          >
          <MaterialButton class="w-auto me-2" color="white" variant="outline"
          >White
          </MaterialButton
          >
        </div>
      </div>
    </div>
  </section>
</template>
