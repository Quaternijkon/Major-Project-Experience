<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Alerts page components
import SimpleAlerts from "./components/SimpleAlerts.vue";

// Alerts page components codes
import { simpleAlertsCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[
      { label: 'Attention Catchers', route: '#' },
      { label: 'Alerts' },
    ]"
    title="Alerts"
  >
    <View
      id="simple-alerts"
      :code="simpleAlertsCode"
      height="600"
      title="Simple Alerts"
    >
      <SimpleAlerts />
    </View>
  </BaseLayout>
</template>
