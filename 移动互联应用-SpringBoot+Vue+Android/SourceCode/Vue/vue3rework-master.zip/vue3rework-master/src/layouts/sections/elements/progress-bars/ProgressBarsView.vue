<script setup>
import { onMounted } from "vue";

// Sections components
import BaseLayout from "../../components/BaseLayout.vue";
import View from "../../components/View.vue";

// Progress Bars page components
import ProgressSimple from "./components/ProgressSimple.vue";

// Progress Bars page components codes
import { progressSimpleCode } from "./components/codes";

//nav-pills
import setNavPills from "@/assets/js/nav-pills";

//hook
onMounted(() => {
  setNavPills();
});
</script>
<template>
  <BaseLayout
    :breadcrumb="[
      { label: 'Elements', route: '#' },
      { label: 'Progress Bars' },
    ]"
    title="Progress Bars"
  >
    <View
      id="progress-simple"
      :code="progressSimpleCode"
      title="Progress Bars Simple"
    >
      <ProgressSimple />
    </View>
  </BaseLayout>
</template>
