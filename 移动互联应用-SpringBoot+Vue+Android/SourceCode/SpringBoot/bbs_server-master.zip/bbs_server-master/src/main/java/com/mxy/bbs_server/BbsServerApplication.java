package com.mxy.bbs_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbsServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(BbsServerApplication.class, args);
    }

}
