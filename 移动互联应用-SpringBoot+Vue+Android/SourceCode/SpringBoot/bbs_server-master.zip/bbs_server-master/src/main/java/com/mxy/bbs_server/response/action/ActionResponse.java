package com.mxy.bbs_server.response.action;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ActionResponse {
    private Boolean success;
}
