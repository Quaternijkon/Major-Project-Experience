package com.mxy.bbs_server.response.review;

public enum ReviewResponseFailedReason {
    REVIEW_ALREADY_EXISTS,
    REVIEW_DOES_NOT_EXISTS
}
