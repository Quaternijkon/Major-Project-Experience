package com.mxy.bbs_server.response.user;

public enum UserResponseFailedReason {
    USERNAME_ALREADY_EXIST,
    USERNAME_DOES_NOT_EXIST,
    WRONG_PASSWORD,
}
