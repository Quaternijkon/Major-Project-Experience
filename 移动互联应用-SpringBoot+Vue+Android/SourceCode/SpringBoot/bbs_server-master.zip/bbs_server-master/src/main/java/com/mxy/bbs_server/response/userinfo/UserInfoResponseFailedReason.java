package com.mxy.bbs_server.response.userinfo;

public enum UserInfoResponseFailedReason {
    USERNAME_DOES_NOT_EXIST
}
