package com.mxy.bbs_server.response.post;

public enum PostResponseFailedReason {
    POST_DOES_NOT_EXIST,
    POST_ALREADY_EXISTS,
}
