package com.mxy.bbs_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BbsServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
