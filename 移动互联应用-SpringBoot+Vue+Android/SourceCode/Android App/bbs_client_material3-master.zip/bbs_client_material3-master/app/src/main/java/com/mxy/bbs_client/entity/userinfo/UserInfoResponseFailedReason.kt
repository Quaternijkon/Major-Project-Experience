package com.mxy.bbs_client.entity.userinfo

enum class UserInfoResponseFailedReason {
    USERNAME_DOES_NOT_EXIST
}