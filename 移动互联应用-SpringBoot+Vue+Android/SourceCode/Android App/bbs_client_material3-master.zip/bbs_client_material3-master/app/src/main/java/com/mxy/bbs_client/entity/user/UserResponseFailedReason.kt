package com.mxy.bbs_client.entity.user

enum class UserResponseFailedReason {
    USERNAME_ALREADY_EXIST,
    USERNAME_DOES_NOT_EXIST,
    WRONG_PASSWORD,
}