package com.mxy.bbs_client.entity.postlist

data class PostListResponse(
    val success: Boolean,
    val postIds: List<String>
)
