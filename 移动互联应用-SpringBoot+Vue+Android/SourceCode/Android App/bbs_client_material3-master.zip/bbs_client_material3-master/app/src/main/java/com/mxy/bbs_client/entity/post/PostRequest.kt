package com.mxy.bbs_client.entity.post

