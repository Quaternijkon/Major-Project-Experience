package com.mxy.bbs_client.serverinfo

const val serverUrl = "http://8.130.13.195:12345"

const val jsonMediaType = "application/json"

const val DefaultAvatarUrl = "http://8.130.13.195:8086/home/nginx_root/assembled_server/server/avatars/default.png"

