package com.mxy.bbs_client.entity.post

enum class PostResponseFailedReason {
    POST_DOES_NOT_EXIST,
    POST_ALREADY_EXISTS,
}