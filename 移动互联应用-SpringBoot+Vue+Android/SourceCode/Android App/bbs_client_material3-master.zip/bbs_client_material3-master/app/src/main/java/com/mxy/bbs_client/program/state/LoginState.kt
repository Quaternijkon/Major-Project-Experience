package com.mxy.bbs_client.program.state

data class LoginState(
    val userInfoState: UserInfoState,

)