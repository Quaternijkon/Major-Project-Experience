package com.mxy.bbs_client.entity.review

enum class ReviewResponseFailedReason {
    REVIEW_ALREADY_EXISTS,
    REVIEW_DOES_NOT_EXISTS
}