package com.mxy.bbs_client.entity.action

data class ActionResponse(
    val success: Boolean?
)
