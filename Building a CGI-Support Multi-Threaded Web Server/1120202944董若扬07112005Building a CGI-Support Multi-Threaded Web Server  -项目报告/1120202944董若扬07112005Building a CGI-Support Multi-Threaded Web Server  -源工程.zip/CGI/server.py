import os
import socket
import threading
import time

from worker import tasks, working_thread, Worker, sema

# 从用户输入获取最大连接数
try:
    max_connection = eval(input("请输入最大连接数："))
except:
    max_connection = 128

# 设置服务器的端口号
port = 8888

# 创建服务器套接字并绑定到指定端口
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host_name = socket.gethostname()
host_name = socket.gethostbyname(host_name)
address = ("0.0.0.0", port)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # 允许地址重用
server_socket.bind(address)
server_socket.settimeout(60)  # 防止服务器长时间无响应
server_socket.listen(max_connection)  # 最大连接数

print(host_name + ':' + str(port))


class ThreadPool(threading.Thread):
    """
    线程池类，用于创建 Worker 线程
    """

    def __init__(self, log_name):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.start()
        self.log_name = log_name

    def run(self):
        # 创建日志目录
        log_dir = 'log'
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        # 以当前时间为文件名创建日志文件
        log_name = os.path.join(log_dir, time.strftime("%Y-%m-%d-%H-%M-%S.txt", time.localtime()))
        # 创建 Worker 线程
        for i in range(max_connection):
            Worker(log_name)
        # 循环检查任务队列和工作线程状态
        while True:
            for i in range(10):
                if (len(working_thread) == max_connection
                        and max_connection != 0 and (not tasks.empty())):
                    print("shutdown")
                    working_thread[0].restart()
            sema.acquire(timeout=1)


# 创建线程池
now_time = time.localtime()
log_dir = 'log'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)
log_name = os.path.join(log_dir, time.strftime("%Y-%m-%d-%H-%M-%S.txt", time.localtime()))

ThreadPool(log_name)

# 循环监听客户端连接
while True:
    try:
        client, addr = server_socket.accept()
        print("recv: ", client.getpeername(), client.getsockname())
        # 将客户端套接字加入任务队列
        tasks.put(client)

    except socket.timeout:
        print("main server timeout")
