import os
import subprocess
import threading
import time
from queue import Queue

tasks = Queue()  # 创建任务队列
working_thread = list()  # 创建工作线程列表

sema = threading.Semaphore()  # 创建信号量对象


class Worker(threading.Thread):  # 工作线程类
    def __init__(self, log_name):  # 初始化方法，传入日志文件名
        self.file_handle = None
        self.socket = None
        self.proc = None
        threading.Thread.__init__(self)
        self.setDaemon(True)  # 设置为守护线程
        self.start()

        self.log_name = log_name  # 日志文件名
        self.msg = None  # 请求信息
        self.status_code = -1  # 状态码

    def restart(self):  # 重启方法，关闭相关资源
        if self.file_handle is not None:
            self.file_handle.close()
            self.file_handle = None
        if self.socket is not None:
            try:
                self.socket.shutdown(2)
                self.socket.close()
            except Exception as e:
                print("socket error:", e)
            self.socket = None
        if self.proc is not None and self.proc.poll() is not None:
            self.proc.kill()
            self.proc = None

    def get(self, file_name, is_head=False):  # 处理GET请求
        if os.path.isfile(file_name):  # 文件存在
            file_suffix = file_name.split('.')
            file_suffix = file_suffix[-1].encode()
            content = b"HTTP/1.1 200 OK\r\nContent-Type: text/" + file_suffix + b";charset=utf-8\r\n"

            self.status_code = 200  # 状态码为200
        else:  # 文件不存在
            content = b"HTTP/1.1 404 Not Found\r\nContent-Type: text/html;charset=utf-8\r\n"
            file_name = "404.html"

            self.status_code = 404  # 状态码为404
        content += b'\r\n'
        self.socket.sendall(content)

        file_size = 0

        if not is_head:  # 不是HEAD请求，发送文件内容
            self.file_handle = open(file_name, "rb")
            for line in self.file_handle:
                self.socket.sendall(line)

            file_size = os.path.getsize(file_name)

        print(self.log_name)  # 输出日志文件名
        self.write_log(file_size)  # 写入日志

    def post(self, file_name, args):  # 处理POST请求
        command = 'python ' + file_name + ' "' + args + '" "' + self.socket.getsockname(
        )[0] + '" "' + str(self.socket.getsockname()[1]) + '"'  # 执行请求的命令
        self.proc = subprocess.Popen(command,
                                     shell=True,
                                     stdout=subprocess.PIPE)
        self.proc.wait()

        file_size = 0

        if self.proc.poll() == 2:  # 执行命令失败
            content = b"HTTP/1.1 403 Forbidden\r\nContent-Type: text/html;charset=utf-8\r\n"
            page = b''
            self.file_handle = open("403.html", "rb")
            for line in self.file_handle:
                page += line
            content += b'\r\n'
            content += page

            self.status_code = 403  # 状态码为403
        else:  # 执行命令成功
            content = b"HTTP/1.1 200 OK\r\nContent-Type: text/html;charset=utf-8\r\n"
            content += self.proc.stdout.read()

            file_size = os.path.getsize(file_name)
            self.status_code = 200  # 状态码为200
        self.socket.sendall(content)
        print(self.log_name)  # 输出日志文件名
        self.write_log(file_size)  # 写入日志

    def head(self, file_name):  # 处理HEAD请求
        if os.path.isfile(file_name):  # 文件存在
            file_suffix = file_name.split('.')
            file_suffix = file_suffix[-1].encode()
            content = b"HTTP/1.1 200 OK\r\nContent-Type: text/" + file_suffix + b";charset=utf-8\r\n"
            self.status_code = 200  # 状态码为200
        else:  # 文件不存在
            content = b"HTTP/1.1 404 Not Found\r\nContent-Type: text/html;charset=utf-8\r\n"
            file_name = "404.html"
            self.status_code = 404
            content += b'\r\n'
        self.socket.sendall(content)
        self.write_log(0)  # 传入文件大小为0，表示只是响应头

    def write_log(self, file_size):  # 日志书写（文件大小）
        content = self.msg[1].split(":")[1].replace(" ", "")
        content = content + "--"
        content = content + "[" + str(time.localtime().tm_year) + "-" + str(
            time.localtime().tm_mon) + "-" + str(
            time.localtime().tm_mday) + "-" + str(
            time.localtime().tm_hour) + "-" + str(
            time.localtime().tm_min) + "-" + str(
            time.localtime().tm_sec) + "]"
        content = content + " " + self.msg[0].split("/")[0].replace(" ",
                                                                    "") + " "
        content = content + " " + self.msg[0].split(" ")[1].replace(" ",
                                                                    "") + " "
        content = content + str(file_size) + " "
        content = content + str(self.status_code) + " "
        for i in self.msg:
            if i.split(" ")[0] == "Referer:":  # 如果请求信息包含Referer，写入到日志中
                content = content + i.split(" ")[1].replace(" ", "")

        content = content + "\n"

        with open(self.log_name, "a") as f:  # 写入日志文件
            f.write(content)

    def run(self):  # 线程运行方法
        while True:
            self.socket = tasks.get()  # 从任务队列中获取socket对象
            working_thread.append(self)  # 将当前线程添加到工作线程列表中
            sema.release()  # 释放信号量

            message = self.socket.recv(8000).decode("utf-8")  # 接收请求信息
            message = message.splitlines()

            self.msg = message  # 保存请求信息

            if message:
                key_mes = message[0].split()
            else:
                self.restart()  # 如果请求信息为空，则重启线程
                continue
            if len(key_mes) <= 1:
                self.restart()  # 如果请求信息格式不正确，则重启线程
                continue
            file_name = "index.html"
            if key_mes[1] != "/":
                file_name = key_mes[1][1:]

            working_thread.append(self)  # 将当前线程添加到工作线程列表中
            try:
                if key_mes[0] == 'GET':
                    self.get(file_name)
                elif key_mes[0] == 'POST':
                    self.post(file_name, message[-1])
                elif key_mes[0] == 'HEAD':
                    self.head(file_name)
                else:
                    content = b"HTTP/1.1 400 Bad Request\r\nContent-Type: text/html\r\n"
                    self.socket.sendall(content)
            except Exception as e:
                print("reason:", e)  # 输出异常信息
            self.restart()  # 重启线程
            working_thread.remove(self)  # 将当前线程从工作线程列表中删除
            sema.release()  # 释放信号量
